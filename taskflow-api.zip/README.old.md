# taskflow-api
Taskflow API is a modular and scalable task management API built with NestJS. It provides a clean, organized backend architecture for creating, updating, organizing, and tracking tasks — complete with support for priorities, due dates, statuses, and categories.

